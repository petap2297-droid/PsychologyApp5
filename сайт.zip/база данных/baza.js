// --- КОНФИГУРАЦИЯ FIREBASE ---
const firebaseConfig = {
    apiKey: "AIzaSyDhNDIqWxL3OOghO0xHNJZB8DHuO9AAI5U",
    authDomain: "psychologyapp-2e04e.firebaseapp.com",
    projectId: "psychologyapp-2e04e",
    storageBucket: "psychologyapp-2e04e.firebasestorage.app",
    messagingSenderId: "761176989986",
    appId: "1:761176989986:web:e34e8e2fec68449471057b",
};

// Инициализация
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// --- ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ---
let currentUser = null;
let isAdmin = false;
let statsChart = null;
let questionsData = [], chatsData = [], usersData = [], alarmsData = [], testsData = [];

// --- ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ ---
document.addEventListener('DOMContentLoaded', () => {
    auth.onAuthStateChanged(async (user) => {
        if (user) {
            const userDoc = await db.collection('users').doc(user.uid).get();
            if (userDoc.exists) {
                currentUser = { uid: user.uid, ...userDoc.data() };
                isAdmin = currentUser.role === 'admin';
                updateUI(true);
            }
        } else {
            currentUser = null;
            isAdmin = false;
            updateUI(false);
        }
    });
});

// --- UI И МОДАЛЬНЫЕ ОКНА ---
function updateUI(isLoggedIn) {
    document.getElementById('loginBtnContainer').style.display = isLoggedIn ? 'none' : 'block';
    document.getElementById('registerBtnContainer').style.display = isLoggedIn ? 'none' : 'block';
    document.getElementById('adminQuickBtnContainer').style.display = isLoggedIn ? 'none' : 'block';
    document.getElementById('profileBtnContainer').style.display = isLoggedIn ? 'block' : 'none';
    document.getElementById('logoutBtnContainer').style.display = isLoggedIn ? 'block' : 'none';
    document.getElementById('adminBtnContainer').style.display = isLoggedIn && isAdmin ? 'block' : 'none';
}

function showLoginModal() {
    document.getElementById('authModal').style.display = 'block';
    document.getElementById('loginFormBlock').style.display = 'block';
    document.getElementById('registerFormBlock').style.display = 'none';
    document.getElementById('adminLoginFormBlock').style.display = 'none';
}

function showRegisterModal() {
    document.getElementById('authModal').style.display = 'block';
    document.getElementById('loginFormBlock').style.display = 'none';
    document.getElementById('registerFormBlock').style.display = 'block';
    document.getElementById('adminLoginFormBlock').style.display = 'none';
}

function showAdminLoginModal() {
    document.getElementById('authModal').style.display = 'block';
    document.getElementById('loginFormBlock').style.display = 'none';
    document.getElementById('registerFormBlock').style.display = 'none';
    document.getElementById('adminLoginFormBlock').style.display = 'block';
}

function closeAuthModal() { document.getElementById('authModal').style.display = 'none'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

// --- АВТОРИЗАЦИЯ ---
async function register() {
    const name = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const pass = document.getElementById('regPass').value;

    if (!name || !email || !pass) return alert('Пожалуйста, заполните все поля.');
    if (name.length < 3) return alert('Имя пользователя должно быть не короче 3 символов.');

    const userQuery = await db.collection('users').where('username_lowercase', '==', name.toLowerCase()).get();
    if (!userQuery.empty) return alert('Это имя пользователя уже занято. Пожалуйста, выберите другое.');
    
    try {
        const cred = await auth.createUserWithEmailAndPassword(email, pass);
        await db.collection('users').doc(cred.user.uid).set({
            username: name,
            username_lowercase: name.toLowerCase(),
            email: email,
            role: 'user',
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        closeAuthModal();
        alert('Регистрация успешна!');
    } catch (e) {
        if (e.code === 'auth/email-already-in-use') alert('Этот email уже зарегистрирован.');
        else if (e.code === 'auth/invalid-email') alert('Некорректный формат email.');
        else alert('Ошибка регистрации: ' + e.message);
    }
}

async function login() {
    const identifier = document.getElementById('loginIdentifier').value.trim();
    const pass = document.getElementById('loginPass').value;
    if (!identifier || !pass) return alert('Заполните все поля');

    let loginEmail = identifier;

    if (!identifier.includes('@')) {
        try {
            const userQuery = await db.collection('users').where('username_lowercase', '==', identifier.toLowerCase()).limit(1).get();
            if (userQuery.empty) return alert('Пользователь с таким именем или email не найден.');
            loginEmail = userQuery.docs[0].data().email;
        } catch (error) { return alert('Ошибка при поиске пользователя: ' + error.message); }
    }
    
    try {
        await auth.signInWithEmailAndPassword(loginEmail, pass);
        closeAuthModal();
        alert('Успешный вход!');
    } catch (e) {
        if (e.code === 'auth/user-not-found' || e.code === 'auth/wrong-password' || e.code === 'auth/invalid-credential') {
            alert('Неверные учетные данные.');
        } else alert('Ошибка: ' + e.message);
    }
}

async function loginAdmin() {
    const identifier = document.getElementById('adminLoginIdentifier').value.trim();
    const pass = document.getElementById('adminLoginPass').value;
    if (!identifier || !pass) return alert('Заполните все поля');

    let loginEmail = identifier;
    if (!identifier.includes('@')) {
        try {
            const userQuery = await db.collection('users').where('username_lowercase', '==', identifier.toLowerCase()).limit(1).get();
            if (userQuery.empty) return alert('Администратор с таким именем или email не найден.');
            loginEmail = userQuery.docs[0].data().email;
        } catch (error) { return alert('Ошибка при поиске администратора: ' + error.message); }
    }

    try {
        const userCredential = await auth.signInWithEmailAndPassword(loginEmail, pass);
        const userDoc = await db.collection('users').doc(userCredential.user.uid).get();

        if (userDoc.exists && userDoc.data().role === 'admin') {
            await openAdminPanel();
            closeAuthModal();
        } else {
            await auth.signOut();
            alert('Доступ запрещен. У вас нет прав администратора.');
        }
    } catch (e) {
        if (e.code === 'auth/user-not-found' || e.code === 'auth/wrong-password' || e.code === 'auth/invalid-credential') {
            alert('Неверные учетные данные администратора.');
        } else alert('Ошибка входа: ' + e.message);
    }
}

async function logout() {
    if (document.getElementById('adminPanel').classList.contains('active')) closeAdminPanel();
    await auth.signOut();
}

async function quickAdminLogin() {
    const adminEmail = 'admin@garmonia.app';
    const adminPass = 'admin123';
    try {
        await auth.signInWithEmailAndPassword(adminEmail, adminPass);
    } catch (e) {
        if (e.code === 'auth/user-not-found' || e.code === 'auth/invalid-credential') {
            try {
                const cred = await auth.createUserWithEmailAndPassword(adminEmail, adminPass);
                await db.collection('users').doc(cred.user.uid).set({ username: 'admin', username_lowercase: 'admin', email: adminEmail, role: 'admin', createdAt: new Date() });
                await auth.signInWithEmailAndPassword(adminEmail, adminPass);
            } catch (err) { alert(err.message); }
        } else { alert('Ошибка быстрого входа: ' + e.message); }
    }
}

// --- ОТПРАВКА ЗАЯВКИ ---
async function submitAlarm() {
    const name = document.getElementById('alarmName').value;
    const text = document.getElementById('alarmText').value;
    if(!name || !text) return alert('Заполните все поля');
    try {
        await db.collection('alarms').add({ username: name, alarms: text, createdAt: firebase.firestore.FieldValue.serverTimestamp(), status: 'new' });
        document.getElementById('alarmForm').reset();
        alert('Заявка успешно отправлена!');
    } catch(e) { alert('Ошибка отправки: ' + e.message); }
}

// --- АДМИН ПАНЕЛЬ: ЛОГИКА ---
async function openAdminPanel() {
    document.getElementById('adminPanel').classList.add('active');
    document.body.style.overflow = 'hidden';
    await loadAllData();
    showAdminSection('stats');
}

function closeAdminPanel() {
    document.getElementById('adminPanel').classList.remove('active');
    document.body.style.overflow = 'auto';
}

function showAdminSection(secId) {
    document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
    document.getElementById(secId + 'Section').classList.add('active');
    
    document.querySelectorAll('.admin-menu-btn').forEach(b => b.classList.remove('active'));
    const activeButton = document.querySelector(`.admin-menu-btn[onclick*="'${secId}'"]`);
    if (activeButton) activeButton.classList.add('active');
}

// --- ЗАГРУЗКА И РЕНДЕР ДАННЫХ ---
async function loadAllData() {
    const [qSnap, mSnap, aSnap, uSnap, tSnap] = await Promise.all([
        db.collection('questions').orderBy('id').get(),
        db.collection('messages').orderBy('timestamp').get(),
        db.collection('alarms').orderBy('createdAt', 'desc').get(),
        db.collection('users').get(),
        db.collection('testResults').get()
    ]);

    questionsData = qSnap.docs.map(d => ({ docId: d.id, ...d.data() }));
    renderQuestions();

    let groups = {};
    mSnap.docs.forEach(d => {
        const msg = d.data();
        if(!msg.senderName || !msg.receiverId) return;
        let key = [msg.senderName, msg.receiverId].sort().join('-');
        if(!groups[key]) groups[key] = { participants: key, msgs: [] };
        groups[key].msgs.push(msg);
    });
    chatsData = Object.values(groups);
    renderChats();

    alarmsData = aSnap.docs.map(d => ({ docId: d.id, ...d.data() }));
    renderAlarms();

    usersData = uSnap.docs.map(d => ({ docId: d.id, ...d.data() }));
    testsData = tSnap.docs.map(d => d.data());
    renderUsers();

    updateStats();
}

function renderQuestions() {
    const tbody = document.getElementById('questionsTableBody');
    let html = '';
    questionsData.forEach(q => {
        html += `<tr><td>${q.id}</td><td>${q.category}</td><td>${q.text}</td><td><small>${(q.options || []).join(', ')}</small></td><td><button class="btn btn-small" onclick='editQuestion("${q.docId}")'><i class="fas fa-edit"></i></button><button class="btn btn-small btn-danger" onclick='delQuestion("${q.docId}")'><i class="fas fa-trash"></i></button></td></tr>`;
    });
    tbody.innerHTML = html;
}

function renderChats() {
    const tbody = document.getElementById('chatsTableBody');
    let html = '';
    chatsData.forEach(chat => {
        const lastMsg = chat.msgs.length > 0 ? chat.msgs[chat.msgs.length - 1] : null;
        const date = lastMsg && lastMsg.timestamp ? new Date(lastMsg.timestamp.seconds * 1000).toLocaleString() : '-';
        const msgText = lastMsg ? lastMsg.message.substring(0, 50) + '...' : 'Нет сообщений';
        html += `<tr><td>${chat.participants}</td><td>${msgText}</td><td>${date}</td><td><button class="btn btn-small" onclick='viewChat("${chat.participants}")'>Открыть</button></td></tr>`;
    });
    tbody.innerHTML = html;
}

function renderAlarms() {
    const tbody = document.getElementById('alarmsTableBody');
    let html = '';
    alarmsData.forEach(a => {
        const date = a.createdAt ? new Date(a.createdAt.seconds * 1000).toLocaleDateString() : '-';
        html += `<tr><td>${a.username}</td><td>${a.alarms}</td><td>${date}</td><td><button class="btn btn-small btn-danger" onclick="delAlarm('${a.docId}')">Удалить</button></td></tr>`;
    });
    tbody.innerHTML = html;
}

function renderUsers() {
    const tbody = document.getElementById('usersTableBody');
    let html = '';
    usersData.forEach(u => {
        const userTests = testsData.filter(t => t.userId === u.docId);
        html += `<tr><td>${u.username || 'Без имени'}</td><td>${u.email || '-'}</td><td>${u.role}</td><td>${userTests.length}</td><td><button class="btn btn-small" onclick='showUserDetails("${u.docId}")'>Детали</button></td></tr>`;
    });
    tbody.innerHTML = html;
}

// --- СТАТИСТИКА И CRUD ---
function updateStats() {
    document.getElementById('countChats').textContent = chatsData.length;
    document.getElementById('countUsers').textContent = usersData.length;
    document.getElementById('countTests').textContent = testsData.length;
    document.getElementById('countQuestions').textContent = questionsData.length;
    document.getElementById('countAlarms').textContent = alarmsData.length;
    const ctx = document.getElementById('statsChart').getContext('2d');
    if(statsChart) statsChart.destroy();
    statsChart = new Chart(ctx, { type: 'bar', data: { labels: ['Чаты', 'Пользователи', 'Тесты', 'Вопросы', 'Заявки'], datasets: [{ label: 'Количество', data: [chatsData.length, usersData.length, testsData.length, questionsData.length, alarmsData.length], backgroundColor: 'rgba(46, 139, 87, 0.6)' }] }, options: { responsive: true, maintainAspectRatio: false } });
}

function openQuestionModal() {
    document.getElementById('questionForm').reset();
    document.getElementById('qDocId').value = '';
    document.getElementById('qModalTitle').textContent = 'Новый вопрос';
    document.getElementById('questionModal').style.display = 'block';
}

function editQuestion(docId) {
    const q = questionsData.find(i => i.docId === docId);
    if(!q) return;
    document.getElementById('qDocId').value = docId;
    document.getElementById('qNum').value = q.id;
    document.getElementById('qCat').value = q.category;
    document.getElementById('qText').value = q.text;
    document.getElementById('qOpts').value = (q.options || []).join('\n');
    document.getElementById('qModalTitle').textContent = 'Редактирование вопроса';
    document.getElementById('questionModal').style.display = 'block';
}

async function saveQuestion() {
    const docId = document.getElementById('qDocId').value;
    const data = { id: Number(document.getElementById('qNum').value), category: document.getElementById('qCat').value, text: document.getElementById('qText').value, options: document.getElementById('qOpts').value.split('\n').filter(x => x.trim()) };
    try {
        if (docId) await db.collection('questions').doc(docId).update(data);
        else await db.collection('questions').add(data);
        closeModal('questionModal');
        await loadAllData();
    } catch(e) { alert("Ошибка сохранения: " + e.message); }
}

async function delQuestion(docId) {
    if(confirm('Вы уверены, что хотите удалить этот вопрос?')) {
        try {
            await db.collection('questions').doc(docId).delete();
            await loadAllData();
        } catch(e) { alert("Ошибка удаления: " + e.message); }
    }
}

async function delAlarm(docId) {
    if(confirm('Вы уверены, что хотите удалить эту заявку?')) {
        try {
            await db.collection('alarms').doc(docId).delete();
            await loadAllData();
        } catch(e) { alert("Ошибка удаления: " + e.message); }
    }
}

// --- Функции просмотра деталей ---
function viewChat(participants) {
    const chat = chatsData.find(c => c.participants === participants);
    if (!chat) return alert("Чат не найден");

    let html = `<div style="max-height:400px; overflow-y:auto; background:#f0f0f0; padding:10px; border-radius: 5px;">`;
    if (chat.msgs.length > 0) {
        chat.msgs.forEach(m => {
            const time = m.timestamp ? new Date(m.timestamp.seconds * 1000).toLocaleTimeString() : '';
            html += `<p><strong>${m.senderName}:</strong> ${m.message} <small style="color:#888; float: right;">${time}</small></p>`;
        });
    } else {
        html += `<p>В этом чате пока нет сообщений.</p>`;
    }
    html += `</div>`;
    document.getElementById('detailContent').innerHTML = `<h3>Чат: ${participants}</h3>${html}`;
    document.getElementById('detailModal').style.display = 'block';
}

function showUserDetails(uid) {
    const user = usersData.find(u => u.docId === uid);
    if (!user) return alert("Пользователь не найден");

    const tests = testsData.filter(t => t.userId === uid);
    let html = `<p><strong>Имя:</strong> ${user.username}</p><p><strong>Email:</strong> ${user.email}</p><p><strong>Роль:</strong> ${user.role}</p>`;
    html += `<h4>Пройденные тесты (${tests.length}):</h4>`;
    if (tests.length > 0) {
        html += '<ul>';
        tests.forEach(t => {
            const date = t.date ? new Date(t.date.seconds * 1000).toLocaleDateString() : '-';
            html += `<li>Дата: ${date} - Баллы: ${t.score}</li>`;
        });
        html += `</ul>`;
    } else {
        html += '<p>Этот пользователь еще не проходил тесты.</p>';
    }
    document.getElementById('detailContent').innerHTML = `<h3>Пользователь: ${user.username}</h3>${html}`;
    document.getElementById('detailModal').style.display = 'block';
}

function openProfile() {
    if(!currentUser) return;
    alert(`Ваш профиль:\nИмя: ${currentUser.username}\nEmail: ${currentUser.email}\nРоль: ${currentUser.role}`);
}
